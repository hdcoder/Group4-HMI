const mongoose = require("mongoose");
/*
const tempSchema = new mongoose.Schema({
 bookName:String,
 publisher:String,
 author:String,
 price:Number,
 subject:String

 });

//mongoose.connect('mongodb://localhost/db');
async function f(){
//Note testingdb is db name
// tempbook is collection name
await mongoose.connect('mongodb://localhost:27017/testingdb');
var conn = mongoose.connection;
var  book = mongoose.model("tempbook", tempSchema);
var data={

	"bookName" : "C Complete reference", 
"author" : "A1", 
"publisher" : "Tata mc graw hill", 
"price" : 3512, 
"subject" : "Programming in C"

}

conn.collection('tempbook').insert(data,function(err,r){
	console.log(err);
	console.log(r);
});

mongoose.connection.close();
//console.log(temp1);
//temp1.close();


}

//f();
*/
async function bookInitialize(){

const tempSchema = new mongoose.Schema({
 bookName:String,
 publisher:String,
 author:String,
 price:Number,
 subject:String

 });

await mongoose.connect('mongodb://localhost:27017/testingdb');
var conn = mongoose.connection;
var  book = mongoose.model("tempbook", tempSchema);
return(conn);

}



async function insert1(data){
	var conn =await bookInitialize();

conn.collection('tempbook').insert(data,function(err,r){
	console.log(err);
	console.log(r);
});

conn.close();


}

var data={

	"bookName" : "C Complete reference", 
"author" : "A1", 
"publisher" : "Tata mc graw hill", 
"price" : 3512, 
"subject" : "Programming in C"

}

insert1(data);