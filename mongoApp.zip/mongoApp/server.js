
var express = require('express'); 
var app = express(); 
/**for getting data from post**/
var bodyParser = require('body-parser')

app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
extended: true })); 
app.use(express.json());       // to support JSON-encoded bodies
app.use(express.urlencoded()); // to support URL-encoded bodies

//////////////////////////////

//mongo1=require( './mongo1.js');
//var F=mongo1.mongo1;

mongo3=require( './mongo3.js');
var F=mongo3.mongo3;

// Set EJS as templating engine 
app.set('view engine', 'ejs'); 
app.get('/booking', async (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 
console.log(req.query.bookId);
console.log(req.query.userEmail);
await F.booking(parseInt(req.query.bookId),req.query.userEmail);

var data = {
	email:'',
    books:[]
}; 

data.email=req.query.userEmail;
var list= await F.searchBook('',0);
var i;
console.log(list);

for(i=0;i<list.length;i++)
{ data.books.push(list[i]);}

console.log(data.books);
res.render('home2', {data:data}); }); 

app.get('/allBooks', async (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 

var data = { books:[] }; 

var list= await F.searchBook('',0);
var i;
console.log(list);

for(i=0;i<list.length;i++)
{ data.books.push(list[i]); }

console.log(data.books);
res.render('home2', {data:data}); }); 

app.get('/searchBooks', async (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 
data={
	email:'',
	books:[]
}
console.log(req.query);
var data1={};
if(req.query.bookName!='' && req.query.bookName!=undefined)
	data1['bookName']=req.query.bookName.trim();

if(req.query.author!='' && req.query.author!=undefined)
	data1['author']=req.query.author.trim();
if(req.query.publisher!='' && req.query.publisher!=undefined)
	data1['publisher']=req.query.publisher.trim();
if(req.query.subject!='' && req.query.subject!=undefined)
	data1['subject']=req.query.subject.trim();
console.log(data1);

list = await F.searchBook(data1,0);
console.log("result of search");
//console.log(list);

for(i=0;i<list.length;i++)
{ data.books.push(list[i]);}

data.email=req.query.userEmail;
console.log(data.books);
res.render('home2', {data:data}); 
//res.send('ok');  
}); 

app.post('/checkLogin',async function(req,res){
	console.log(req.body.email);
	console.log(req.body.password);
	
	x={ userEmail:req.body.email,password:req.body.password}
	
var r= await F.login(x);
console.log(r);
 
if(r==false)
{ res.sendFile(__dirname+'/loginFalse.html');}
else
{
var data = {
	email:'',
    books:[]
}; 

data.email=x.userEmail;
var list= await F.searchBook('',0);
var i;
console.log(list);

for(i=0;i<list.length;i++)
{data.books.push(list[i]);}

console.log(data.books);
res.render('home2', {data:data}); 

} });

app.get('/login',function(req,res)
{ res.sendFile(__dirname+'/login.html');})

app.get('/register',function(req,res)
{ res.sendFile(__dirname+'/register.html');})

app.post('/checkRegister',async function(req,res){
	
data
={
	userName:req.body.userName,
	userEmail:req.body.email,
	password:req.body.password,
	contact:req.body.contact,
	address:req.body.address }

	console.log(data);
    var r = await F.register(data);
    console.log(r);
 
if(r==1)
{ res.sendFile(__dirname+'/registerFalse.html');}
else
{ res.sendFile(__dirname+'/login.html');}
	
});



app.get('/',function(req,res)
{ res.sendFile(__dirname+'/index1.html');});


app.get('/adminLogin',function(req,res)
{ res.sendFile(__dirname+'/adminLogin.html');});


app.post('/checkLoginAdmin',async function(req,res)
{
var email = req.body.email;
var password=req.body.password;
if(email=='adminCloud@gmail.com' && password=='pass@123'){
	//res.sendFile(__dirname+'/admin.html');

var data = {
    books:[]
}; 
var list= await F.searchBook('',0);
var i;
console.log(list);


for(i=0;i<list.length;i++){
	data.books.push(list[i]);
}
console.log(data.books);
res.render('adminBookList', {data:data}); 



}
else
res.sendFile(__dirname+'/adminLoginFail.html');



});



app.get('/adminBookList', async (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 

var data = {
    books:[]
}; 
var list= await F.searchBook('',0);
var i;
console.log(list);


for(i=0;i<list.length;i++){
	data.books.push(list[i]);
}
console.log(data.books);
res.render('adminBookList', {data:data}); 
  
}); 


app.get('/searchBooksAdmin', async (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 
data={
	books:[]
}
console.log(req.query);
var data1={};
if(req.query.bookName!='' && req.query.bookName!=undefined)
	data1['bookName']=req.query.bookName.trim();

if(req.query.author!='' && req.query.author!=undefined)
	data1['author']=req.query.author.trim();
if(req.query.publisher!='' && req.query.publisher!=undefined)
	data1['publisher']=req.query.publisher.trim();
if(req.query.subject!='' && req.query.subject!=undefined)
	data1['subject']=req.query.subject.trim();
console.log(data1);

list = await F.searchBook(data1,0);
console.log("result of search");
//console.log(list);

for(i=0;i<list.length;i++){
	data.books.push(list[i]);
}
console.log(data.books);
res.render('adminBookList', {data:data}); 

//res.send('ok');

  
}); 


app.get('/insertBook',function(req,res){
	res.sendFile(__dirname+'/insert.html');
});

app.get('/updateBook',function(req,res){
	res.sendFile(__dirname+'/update.html');
});

app.get('/deleteBook',function(req,res){
	res.sendFile(__dirname+'/delete.html');
});

app.get('/insertBook1',async function(req,res){
var data={
	'bookName':req.query.bookName,
	'author':req.query.author,
	'publisher':req.query.publisher,
	'price':req.query.price,
	'subject':req.query.subject

}

data.price=parseInt(data.price);
await F.insertBookData(data);

var data = {
    books:[]
}; 
var list= await F.searchBook('',0);
var i;
console.log(list);


for(i=0;i<list.length;i++)
{
	data.books.push(list[i]);
}
console.log(data.books);
res.render('adminBookList', {data:data}); 

});

app.get('/updateBook1',async function(req,res){

var data =
{
	'bookId':req.query.bookId,
	'bookName':req.query.bookName,
	'author':req.query.author,
	'publisher':req.query.publisher,
	'price':req.query.price,
	'subject':req.query.subject
}
console.log("data.price");
if(data.price ==''){
	data.price=0;
	console.log(data);
console.log("0");
}
else 
	data.price=parseInt(data.price);

await F.updateBook(parseInt(req.query.bookId),data);

var data = { books:[] }; 
var list= await F.searchBook('',0);

var i;
//console.log(list);


for(i=0;i<list.length;i++)
{ data.books.push(list[i]);}

console.log(data.books);
res.render('adminBookList', {data:data}); 

});

app.get('/deleteBook1',async function(req,res){

await F.removeBook(parseInt(req.query.bookId));

var data = { books:[] };

var list= await F.searchBook('',0);
var i;
console.log(list);

for(i=0;i<list.length;i++)
{
	data.books.push(list[i]);
}

console.log(data.books);
res.render('adminBookList', {data:data}); });

app.get('/bookedBooks', async (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 
console.log(req.query.bookId);
console.log(req.query.userEmail);

var data = {
	email:'',
    books:[]
}; 
var list= await F.searchBook({userEmail:req.query.userEmail},1);
var i;
console.log(list);


for(i=0;i<list.length;i++)
{
	data.books.push(list[i]);
}
console.log(data.books);
data.email=req.query.userEmail;
res.render('userBook', {data:data}); 

}); 


app.get('/unbooking', async (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 
console.log(req.query.bookId);
console.log(req.query.userEmail);

 await F.unbook(req.query.userEmail,parseInt(req.query.bookId));


var data = {
	email:'',
    books:[]
};

data.email=req.query.userEmail;

var list= await F.searchBook('',0);

var i;
console.log("marked see user");
console.log(data)
console.log(list);

for(i=0;i<list.length;i++){

	data.books.push(list[i]);

}

console.log(data.books);

res.render('home2', {data:data}); 

}); 



app.get('/editProfile',async function(req,res){
	
/*	data={
	userName:req.body.userName,
	userEmail:req.body.email,
	password:req.body.password,
	contact:req.body.contact
}

	console.log(data);
 await F.updateUser(data.userEmail,data);
 


var data1 = {
	email:'',
    books:[]
}; 
data1.email=data.userEmail;
var list= await F.searchBook('',0);
var i;
console.log(list);
for(i=0;i<list.length;i++){
	data1.books.push(list[i]);
}
console.log(data1.books);
res.render('home2', {data:data}); 




*/

console.log(req.query.userEmail);

var l =await F.searchUser({userEmail:req.query.userEmail});
data={
	email:req.query.userEmail,
	userName:l[0].userName,
	contact:l[0].contact,
	password:l[0].password,
	address:l[0].address
}
console.log(data);

res.render('editProfile.ejs', {data:data}); 

});



app.post('/updateProfile',async function(req,res){
	
	data={
	userName:req.body.userName,
	password:req.body.password,
	contact:req.body.contact,
	address:req.body.address
}
console.log(req.body.email);
	console.log(data);
	
 await F.updateUser(req.body.email,data);
 


var data1 = {
	email:req.body.email,
    books:[]
}; 
var list= await F.searchBook('',0);
var i;
console.log(list);
for(i=0;i<list.length;i++){
	data1.books.push(list[i]);
}
console.log(data1.books);
res.render('home2', {data:data1}); 





});

app.get('/logout',function(req,res){
	res.sendFile(__dirname+'/index1.html');

});

app.get('/home2EJS.css',function (req,res){
	res.sendFile(__dirname+'/home2EJS.css');

});

app.get('/design6.jpg',function (req,res){
	res.sendFile(__dirname+'/design6.jpg');

});

app.get('/ccImg1.PNG',function (req,res){
	res.sendFile(__dirname+'/ccImg1.PNG');

});

app.get('/userActivity', async (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 

var data = {
    books:[]
}; 
var list= await F.Test1();
console.log(list);


for(i=0;i<list.length;i++){
	data.books.push(list[i]);
}
console.log(data.books);
res.render('userActivity', {data:data}); 


}); 




var server = app.listen(8080, function(){ 
    console.log('listening to port 8080') 
});




