var MongoClient = require('mongodb').MongoClient;




async function insertBookData(data){
/*
data ={  
"bookName" : "C Complete reference", 
"author" : "A1", 
"publisher" : "Tata mc graw hill", 
"price" : 3512, 
"subject" : "Programming in C"
}
*/


	var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
	var db= client.db("cloudProject");
	var cursor =await db.collection('book').find();
	var list= await cursor.toArray();
	if(list.length!=0){
		var id = list[list.length-1].id;
		id=id+1;
		data["id"]=id;
	}
	else
		data["id"]=1

	data["booked"]=0;
	data["userEmail"]='';


	var r = await db.collection('book').insert(data);
	console.log("book data inserted!");
	client.close();

}





async function searchBook(data,flag){
	//data={"booked":0};
	//data={"author":'a1'};
	// flag ==1 means get all booked and unbooked
	// flag== 0 means get all unbooked 
	if(flag===0){
		if(data==''){
			data={booked:0};
		}
		else{
			data.booked=0;
		}
	}

	var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
	var db= client.db("cloudProject");
	var cursor =await db.collection('book').find(data);
	var list= await cursor.toArray();
	console.log(list);
	client.close();
	return(list);
}


//searchBook(data);

async function updateBook(id,data){
/*
data={
	"bookName" : "", 
"author" : "Deep", 
"publisher" : "", 
"price" : 9999, 
"subject" : "",
}

*/

	var temp;
	temp ={  
"bookName" : "", 
"author" : "", 
"publisher" : "", 
"price" : 0, 
"subject" : ""
}
	var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
	var db= client.db("cloudProject");
  	var l = await searchBook({'id':id},1);
  	if(l.length==0){
  		client.close();
  		return;
  	}
  	console.log(data['bookName']!='')
  	if(data['bookName']!=''){
  		temp.bookName=data['bookName'];
  	}
  	else
  		temp['bookName']=l[0].bookName;

 	if(data['author']!=''){
  		temp['author']=data['author'];
  	}
  	else
  		temp['author']=l[0].author;
 
 	if(data['publisher']!=''){
  		temp['publisher']=data['publisher'];
  	}
  	else
  		temp['publisher']=l[0].publisher;
 
 	if(data['price']!=''){
  		temp['price']=data['price'];
  	}
  	else
  		temp['price']=l.price;
  	if(data['subject']!=''){
  		temp['subject']=data['subject'];
  	}
  	else
  		temp['subject']=l[0].subject;
 

 



 	console.log(temp);


   var r = await	db.collection('book').update({'id':id},{$set:{"bookName":temp["bookName"],"publisher":temp["publisher"],"price":temp["price"],"author":temp["author"],"subject":temp["subject"]}});
   console.log('book data updated!');
  client.close();

}

//updateBook(7,data);
async function removeBook(id){
// give id
var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
var db= client.db("cloudProject");
var l = await searchBook({"id":id},1);
if (l.length==0){
	client.close();
	return;
}

var r = await db.collection('book').remove({'id':id});
console.log("book data removed!");
client.close();

}

async function resetBook(){
	var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
	var db= client.db("cloudProject");
	var r  = await db.collection('book').remove();
	console.log("book collection reset!");
	client.close();

}


/*
data ={  
"bookName" : "C Complete reference", 
"author" : "A1", 
"publisher" : "Tata mc graw hill", 
"price" : 3512, 
"subject" : "Programming in C"
}
insertBookData(data);
*/

////////////////////user///////////////////////////

async function insertUserData(data){
	var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
	var db= client.db("cloudProject");
	//var data={'temp1':2,'temp2':'123'};
	var cursor =await db.collection('user').find();
	var list= await cursor.toArray();
	if(list.length!=0){
		var id = list[list.length-1].id;
		id=id+1;
		data["id"]=id;
	}
	else
		data["id"]=1


	var r = await db.collection('user').insert(data);
	console.log('user data inserted!');
	client.close();

}



data={
	userName:'Deep Dalal',
	userEmail:'dalaldeep23@gmail.com',
	password:'123',
	contact:'8898794818'
}
//insertUserData(data);

async function searchUser(data){
	var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
	var db= client.db("cloudProject");
	var cursor = await db.collection('user').find(data);
	var list= await cursor.toArray();
	console.log(list);
	client.close();
	return(list);

}


data={
	userEmail:'dalaldeep23@gmail.com',
	password:'123'
}
//searchUser(data);

async function register(data){
	var l = await searchUser({'userEmail':data['userEmail']});
	if(l.length!=0){
		console.log("email already there ");
		return(1);
	}
	insertUserData(data);
	return(0);
}

data={
	userName:'Deep Dalal',
	userEmail:'a@gmail.com',
	password:'123',
	contact:'8898794818'
}

//register(data);

async function login(data){
	var l = await searchUser(data);
	var c;
	if(l.length==0)
		c=false;
	else
		c=true;
	console.log(c);
	return(c);
}


data={
userEmail:'h@gmail.com',
	password:'321',

}
//login(data);


async function updateUser(userEmail,data){
/*
data={
	
	userName:'',
	password:'B123B',
	contact:'1231231234'


}
*/

	var temp;
temp={
	userName:'',
	userEmail:'',
	password:'',
	contact:''
}
	var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
	var db= client.db("cloudProject");
  	var l = await searchUser({'userEmail':userEmail});
  	if(l.length==0){
  		client.close();
  		return;
  	}
  	console.log(data['userName']!='')
  	if(data['userName']!=''){
  		temp.userName=data['userName'];
  	}
  	else
  		temp['userName']=l[0].userName;

 	if(data['password']!=''){
  		temp['password']=data['password'];
  	}
  	else
  		temp['password`']=l[0].password;
 
 	if(data['contact']!=''){
  		temp['contact']=data['contact'];
  	}
  	else
  		temp['contact']=l[0].contact;
 
 	console.log(temp);

   var r = await	db.collection('user').update({'userEmail':userEmail},{$set:{"userName":temp["userName"],"password":temp["password"],"contact":temp["contact"]}});
   console.log('user data updated!');
  client.close();

}
//updateUser('a@gmail.com',data)

async function removeUser(userEmail){
// give userEmail
var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
var db= client.db("cloudProject");
var l = await searchUser({"userEmail":userEmail});
if (l.length==0){
	client.close();
	return;
}

var r = await db.collection('user').remove({'userEmail':userEmail});
console.log("user data removed!");
client.close();

}

//removeUser('dalaldeep23@gmail.com');

async function resetUser(){
var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
var db= client.db("cloudProject");
var r = await db.collection('user').remove();
console.log('All user deleted!');
var l =await  searchBook('',1);
var i;
 


for(i=0;i<l.length;i++){
 await db.collection('book').update({"id":l[i].id},{$set:{"booked":0,"userEmail":''}});
}
console.log("All book data booked field reset! and email reset!");
client.close();
}







data ={  
"bookName" : "let us C ", 
"author" : "yashwant", 
"publisher" : "wiley", 
"price" : 9999, 
"subject" : "Programming in C"
}
//insertBookData(data);
//data1 ={ bookName: 'let us C ' };
//console.log(data1);
//searchBook(data1);

async function booking(bookId,userEmail){
	var client = await MongoClient.connect("mongodb://localhost:27017/cloudProject");
	var db= client.db("cloudProject");
	var l = await searchBook({id:bookId},0);
	if(l.length==0){
		console.log('no such book id');
		client.close();
		return;
	}
	if(l[0].booked==1){
		console.log("already booked by some user!");
		client.close();
		return;
	}
	 l = await searchUser({userEmail:userEmail});
	 if(l.length==0){
	 	console.log("no such email id!");

		client.close();
		return;	
	 }


	await db.collection('book').update({id:bookId},{$set:{booked:1,userEmail:userEmail}});
	console.log("Booked!");
	client.close();

	return;

}

//booking(1,'a@gmail.com');

data={
	userName:'Deep Dalal',
	userEmail:'a@gmail.com',
	password:'123',
	contact:'8898794818'
}

//register(data);
//resetUser();
//booking(2,'a@gmail.com');



var mongo1={
        searchBook: function(data,flag){
            return searchBook(data,flag);
        },
        booking:function(bookId,userEmail){
        	return booking(bookId,userEmail);
        },
   		login:function(data){
   			return login(data);
   		},
   		register:function(data){
   			return register(data);
    },

   		insertBookData:function(data){
   			return insertBookData(data);
    },

  		updateBook:function(id,data){
   			return updateBook(id,data);
    },

  		removeBook:function(id){
   			return removeBook(id);
    }



}
exports.mongo1=mongo1;