const mongoose = require("mongoose");
/*
we need to run 
var  book = mongoose.model("tempbook", tempSchema);
 this statement only once to create schema!

*/
async function bookInitialize(){

	const tempSchema = new mongoose.Schema({
	 bookName:String,
	 publisher:String,
	 author:String,
	 price:Number,
	 subject:String,
	 booked:Number,
	 userEmail:String,

	 });

	await mongoose.connect('mongodb://localhost:27017/testingdb');
	//await mongoose.connect('mongodb://mongo:27017/testingdb');
	
	//var  book = mongoose.model("tempbook", tempSchema);


	try {
	var  book =  mongoose.model("tempbook", tempSchema);

	}
	catch(e) {
  	var book =  mongoose.model('tempbook');
	}


	var conn = mongoose.connection;
	return(conn);

}


async function userInitialize(){

	const tempSchema = new mongoose.Schema({
	 userName:String,
	 contact:String,
	 userEmail:String,
	 password:String,
	 id:Number,
	 address:String


	 });

	await mongoose.connect('mongodb://localhost:27017/testingdb');
	//await mongoose.connect('mongodb://mongo:27017/testingdb');
	
	try {
	var  user =  mongoose.model("tempuser", tempSchema);

	}
	catch(e) {
  	var user =  mongoose.model('tempuser');
	}

	var conn = mongoose.connection;
	return(conn);


}

async function insertBookData(data){
/*
data ={  
"bookName" : "C Complete reference", 
"author" : "A1", 
"publisher" : "Tata mc graw hill", 
"price" : 3512, 
"subject" : "Programming in C"
}
*/


	var db = await bookInitialize();
	var cursor =await db.collection('book').find();
	var list= await cursor.toArray();
	if(list.length!=0){
		var id = list[list.length-1].id;
		id=id+1;
		data["id"]=id;
	}
	else
		data["id"]=1

	data["booked"]=0;
	data["userEmail"]='';


	var r = await db.collection('book').insertOne(data);
	console.log("book data inserted!");
	db.close();

}


async function searchBook(data,flag){
	//data={"booked":0};
	//data={"author":'a1'};
	// flag ==1 means get all booked and unbooked
	// flag== 0 means get all unbooked 
	if(flag===0){
		if(data==''){
			data={booked:0};
		}
		else{
			data.booked=0;
		}
	}


	var db = await bookInitialize();
	var cursor =await db.collection('book').find(data);
	var list= await cursor.toArray();
	console.log(list);
	db.close();
	return(list);
}



async function updateBook(id,data){
/*
data={
	"bookName" : "", 
"author" : "Deep", 
"publisher" : "", 
"price" : 9999, 
"subject" : "",
}

*/

	var temp;
	temp ={  
"bookName" : "", 
"author" : "", 
"publisher" : "", 
"price" : 0, 
"subject" : ""
}

  	var l = await searchBook({'id':id},0);
  	if(l.length==0){
  		return;
  	}
  	console.log("hhhhhh");
  	console.log(data);
  	console.log(l);

	var db = await bookInitialize();	

  	console.log(data['bookName']!='')
  	if(data['bookName']!=''){
  		temp.bookName=data['bookName'];
  	}
  	else
  		temp['bookName']=l[0].bookName;

 	if(data['author']!=''){
  		temp['author']=data['author'];
  	}
  	else
  		temp['author']=l[0].author;
 
 	if(data['publisher']!=''){
  		temp['publisher']=data['publisher'];
  	}
  	else
  		temp['publisher']=l[0].publisher;
 
 	if(data['price']!=0){
  		temp['price']=data['price'];
  	}
  	else
  		temp['price']=l[0].price;
  	if(data['subject']!=''){
  		temp['subject']=data['subject'];
  	}
  	else
  		temp['subject']=l[0].subject;
 

 



 	console.log(temp);


   var r = await	db.collection('book').update({'id':id},{$set:{"bookName":temp["bookName"],"publisher":temp["publisher"],"price":temp["price"],"author":temp["author"],"subject":temp["subject"]}});
   console.log('book data updated!');
  db.close();

}


async function removeBook(id){
// give id
	var l = await searchBook({"id":id},1);
	if (l.length==0){
		return;
	}

	var db = await bookInitialize();	
	var r = await db.collection('book').remove({'id':id});
	console.log("book data removed!");
	await db.close();

}


var data={

	"bookName" : "C Complete reference", 
"author" : "A1", 
"publisher" : "Tata mc graw hill", 
"price" : 3512, 
"subject" : "Programming in C"

}

//insertBookData(data);

async function resetBook(){
	var db = await bookInitialize();
	var r  = await db.collection('book').remove();
	console.log("book collection reset!");
	db.close();

}

///////////user////////////////////////////

async function insertUserData(data){
	//var data={'temp1':2,'temp2':'123'};
	var db = await userInitialize();
	var cursor =await db.collection('user').find();
	var list= await cursor.toArray();
	if(list.length!=0){
		var id = list[list.length-1].id;
		id=id+1;
		data["id"]=id;
	}
	else
		data["id"]=1

	var r = await db.collection('user').insert(data);
	console.log('user data inserted!');
	db.close();

}


data={
	userName:'Deep Dalal',
	userEmail:'dalaldeep23@gmail.com',
	password:'123',
	contact:'8898794818'
}
//insertUserData(data);

async function searchUser(data){
	var db = await userInitialize();
	var cursor = await db.collection('user').find(data);
	var list= await cursor.toArray();
	console.log(list);
	db.close();
	return(list);

}

data={
	userEmail:'dalaldeep23@gmail.com',
	password:'123'
}
//searchUser(data);

async function register(data){
	var l = await searchUser({'userEmail':data['userEmail']});
	if(l.length!=0){
		console.log("email already there ");
		return(1);
	}
	await insertUserData(data);
	return(0);
}

data={
	userName:'Deep Dalal',
	userEmail:'x@gmail.com',
	password:'123',
	contact:'8898794818'
}

// register(data);




async function login(data){
	var l = await searchUser(data);
	var c;
	if(l.length==0)
		c=false;
	else
		c=true;
	console.log(c);
	return(c);
}

data={
userEmail:'h@gmail.com',
	password:'123',

}
//login(data);


async function updateUser(userEmail,data){
/*
data={
	
	userName:'',
	password:'B123B',
	contact:'1231231234'


}
*/

	var temp;
temp={
	userName:'',
	userEmail:'',
	password:'',
	contact:''
}

  	var l = await searchUser({'userEmail':userEmail});
  	if(l.length==0){
  		return;
  	}

	var db = await userInitialize();

  	console.log(data['userName']!='')
  	if(data['userName']!=''){
  		temp.userName=data['userName'];
  	}
  	else
  		temp['userName']=l[0].userName;

 	if(data['password']!=''){
  		temp['password']=data['password'];
  	}
  	else
  		temp['password']=l[0].password;
 
 	if(data['contact']!=''){
  		temp['contact']=data['contact'];
  	}
  	else
  		temp['contact']=l[0].contact;
  	if(data['address']!=''){
  		temp['address']=data['address'];
  	}
  	else
  		temp['address']=l[0].address;
 

 
 	console.log(temp);

   var r = await	db.collection('user').update({'userEmail':userEmail},{$set:{"userName":temp["userName"],"password":temp["password"],"contact":temp["contact"],"address":temp["address"]}});
   console.log('user data updated!');
  db.close();

}


data={
	
	userName:'',
	password:'B123B',
	contact:'1231231234'


}

//updateUser('h@gmail.com',data);



async function resetUser(){

var db = await userInitialize();
var r = await db.collection('user').remove();
console.log('All user deleted!');
await db.close();
var l =await  searchBook('',1);
var i;
var  db1 = await bookInitialize();

for(i=0;i<l.length;i++){
 await db1.collection('book').update({"id":l[i].id},{$set:{"booked":0,"userEmail":''}});
}
console.log("All book data booked field reset! and email reset!");
await db1.close();
}


data ={  
"bookName" : "C Complete reference", 
"author" : "A1", 
"publisher" : "Tata mc graw hill", 
"price" : 3512, 
"subject" : "Programming in C"
}
//insertBookData(data);

async function booking(bookId,userEmail){
	var l = await searchBook({id:bookId},0);
	if(l.length==0){
		console.log('no such book id');
		return;
	}
	if(l[0].booked==1){
		console.log("already booked by some user!");
		return;
	}
	 l = await searchUser({userEmail:userEmail});
	 if(l.length==0){
	 	console.log("no such email id!");
		return;	
	 }

	var db = await bookInitialize();
	await db.collection('book').updateOne({id:bookId},{$set:{booked:1,userEmail:userEmail}});
	console.log("Booked!");
	db.close(false);
	return;

}

//booking(7,'x@gmail.com');

async function unbook(userEmail,bookId){
	var l =await searchBook({userEmail:userEmail},1);

	if(l.length==0){
		return;
	}

	var db = await bookInitialize();

	await db.collection('book').updateOne({id:bookId},{$set:{booked:0,userEmail:''}});
	console.log('unbooked!');
	db.close();
	return;
}
async function Test1(){
//await searchUser({});
//await searchBook({},1);
var data={booked:1};
var h={}
var t,d11,o=[];
var l=[]
	var db = await bookInitialize();
	var cursor =await db.collection('book').find(data);
	var list= await cursor.toArray();
	console.log(list);
	for(i=0;i<list.length;i++){
		t={userEmail:list[i].userEmail}
		d11=await searchUser(t);
		l.push({book:list[i],user:d11[0]});
	}
	console.log(l);
	for(i=0;i<l.length;i++){
		console.log(l[i].user.userName,l[i].user.contact,l[i].user.address,l[i].book.id);
		o.push({bookName:l[i].book.bookName,userEmail:l[i].user.userEmail,userName:l[i].user.userName,contact:l[i].user.contact,address:l[i].user.address,id:l[i].book.id})

	}
	console.log(o);
	return(o);
		db.close();
	}
	


var mongo3={
        searchBook: function(data,flag){
            return searchBook(data,flag);
        },
        booking:function(bookId,userEmail){
        	return booking(bookId,userEmail);
        },
   		login:function(data){
   			return login(data);
   		},
   		register:function(data){
   			return register(data);
    },

   		insertBookData:function(data){
   			return insertBookData(data);
    },

  		updateBook:function(id,data){
   			return updateBook(id,data);
    },

  		removeBook:function(id){
   			return removeBook(id);
    },

  		unbook:function(userEmail,bookId){
   			return unbook(userEmail,bookId);
    },

 		updateUser:function(userEmail,data){
   			return updateUser(userEmail,data);
    },

 		searchUser:function(data){
   			return searchUser(data);
    },

    Test1:function(){
   			return Test1();
   		}


}


exports.mongo3 = mongo3;
//unbook('deepu@gmail.com','13');
//Test1();