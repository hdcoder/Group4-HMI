var express = require('express'); 
var app = express(); 
  
// Set EJS as templating engine 
app.set('view engine', 'ejs'); 

app.get('/test', (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 
console.log(req.query.book);
res.send('ok'); 
  
}); 



app.get('/', (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 

var data = {name:'Akashdeep', 
    hobbies:[' football', 'chess', 'cycling','a','b','c','c1','c22','c3']} 
 
res.render('home2', {data:data}); 
  
}); 



app.get('/searchBooks', (req, res)=>{ 
  
// The render method takes the name of the HTML 
// page to be rendered as input 
// This page should be in the views folder 
// in the root directory. 

console.log(req.query.searchBook);
var tep=req.query.searchBook;

var data = {name:'Akashdeep', 
    hobbies:[' football', 'chess', 'cycling','a','b','c','c1','c22','c3']} ;

var d={
	name:'Deep',
	hobbies:[]
}
 for(i=0;i<(data.hobbies.length);i++){
 	if(data.hobbies[i].includes(tep))
 		d.hobbies.push(data.hobbies[i]);

 }
 	console.log(d);

res.render('home2', {data:d}); 
  
}); 



var server = app.listen(4000, function(){ 
    console.log('listining to port 4000') 
});